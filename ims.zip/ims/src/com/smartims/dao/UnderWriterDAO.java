package com.smartims.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.smartims.cc.CC;
import com.smartims.vo.UnderWriterVO;

public class UnderWriterDAO {

	public void insertUnderWriter(UnderWriterVO uvo) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ims?autoReconnect=true&useSSL=false", "root", "root");
			PreparedStatement ps = con.prepareStatement(CC.insertUnderWriter);
			ps.setString(1, uvo.getUw_name());
			ps.setString(2, uvo.getUw_email());
			ps.setString(3, uvo.getPassword());
			int result = ps.executeUpdate();
			if (result > 0)
				System.out.println("Registered UnderWriter Details succesfully with ID:" + uvo.getUw_id());
			else
				System.out.println("Unable to register with ID:" + uvo.getUw_id());
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	//--------
	boolean checkExistance(int uw_id) {
		boolean flag = false;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ims?autoReconnect=true&useSSL=false", "root", "root");
			PreparedStatement ps = con.prepareStatement(CC.displayUnderWriter);
			ps.setInt(1, uw_id);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				flag = true;
			} else {
				flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return flag;
	}

	public void login(int uw_id,String password) {
		UnderWriterVO uvo=new UnderWriterVO();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ims", "root", "root");
			PreparedStatement ps = con.prepareStatement(CC.displayUnderWriter);
			ps.setInt(1, uw_id);
			ps.setString(2, password);
			ResultSet rs = ps.executeQuery();
			if(rs.next()) {
				System.out.println("Successfully Logged In ....");
			}
			else
				System.out.println("No UnderWriter with ID :"+uw_id);
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
