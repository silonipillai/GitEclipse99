package com.smartims.functions;

import java.util.Scanner;

import com.smartims.dao.VehicleDAO;

public class ProductSelection {
	Scanner ip=new Scanner(System.in);
void product() {
	System.out.println("Please select the product :");
	System.out.println("1.Bike Insurance -- 2.Car Insurance -- 3.Exit ");
	String pro=ip.next();
	
	if (pro.equalsIgnoreCase("bike")) {
	
		
			System.out.println("Please Enter Bike Details :");
			VehicleDAO cdao=new VehicleDAO();
			cdao.bike();
	}		
}
}
