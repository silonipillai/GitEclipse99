package com.smartims.action;

import java.util.Scanner;

import com.smartims.dao.AgentDAO;
import com.smartims.vo.AgentVO;

public class RegisterAgentAction {
	Scanner ip = new Scanner(System.in);
	AgentVO avo=new AgentVO();

	void registerAgent() {
		System.out.println("Welcome!!..");
		System.out.println("Register Agent:");

		System.out.println("Enter Name :");
		avo.setAgent_name(ip.next());

		System.out.println("Enter Email :");
		avo.setAgent_email(ip.next());

		System.out.println("Enter Password :");
		avo.setPassword(ip.next());

		AgentDAO adao = new AgentDAO();
		adao.insertAgent(avo);
	}

	public static void main(String[] args) {
		RegisterAgentAction raa = new RegisterAgentAction();
		raa.registerAgent();
	}
}
