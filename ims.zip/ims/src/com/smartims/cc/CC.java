package com.smartims.cc;

public class CC {
	//Agent
	public static String insertAgent="insert into agent (agent_name ,agent_email,password )values(?,?,?)";
	public static String displayAgent="select * from agent where agent_id=? && password=?";
	//Customer
	public static String insertCustomer="insert into customer (cus_name,cus_email,cus_phone,password) values (?,?,?,?)";
	public static String displayCustomer="select * from customer where cus_id=? && password=?";
	//UW
	public static String insertUnderWriter="insert into underwriter (uw_name ,uw_email,password )values(?,?,?)";
	public static String displayUnderWriter="select * from underwriter where uw_id=? && password=?";
	public static String userIdSql="select cus_id from customer";

	
}
